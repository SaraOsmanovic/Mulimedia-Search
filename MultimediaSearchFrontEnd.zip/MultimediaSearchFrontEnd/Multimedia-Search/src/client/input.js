


const checkboxes = document.querySelectorAll('checkbox')

// event listeners
checkboxes.forEach(checkbox => {
    checkbox.addEventListener()
    console.log("accessed")
})

const export_csv = (arrayHeader, arrayData, delimiter, fileName) => {
    let header = arrayHeader.join(delimiter) + '\n';
    let csv = header;
    arrayData.forEach( array => {
        csv += arrayData.join(delimiter)+"\n";
    });

    let csvData = new Blob([csv], { type: 'text/csv' });  
    let csvUrl = URL.createObjectURL(csvData);

    let hiddenElement = document.createElement('a');
    hiddenElement.href = csvUrl;
    hiddenElement.target = '_blank';
    hiddenElement.download = fileName + '.csv';
    hiddenElement.click();
    console.log(csvUrl);
}

let arrayHeader = ["Name","Country","Email"];
let arrayData = ["Sigit Prasetya","Indonesia","sigit@gmail.com"];
    arrayData[1] = ["Song Hye Kyo","South Korea","songsong@gmail.com"];
    arrayData[2] = ["Andy Lau","Hongkong","andyLau@gmail.com"];
    arrayData[3] = ["Enji Shaun","United State","shaun2@gmail.com"];
    arrayData[4] = ["Azumi","Japan","azumiK@gmail.com"];

    // export_csv(arrayHeader, arrayData, ',', "input")
